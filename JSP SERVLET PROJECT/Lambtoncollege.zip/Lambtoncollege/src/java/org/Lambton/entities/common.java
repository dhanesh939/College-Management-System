/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.Lambton.entities;

/**
 *
 * @author Dhanesh
 */
public class common {
    private String email;
    private String password;
    private String role;
    private String user;
    private String insid;
    private String stuid;
    private String grade;
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the role
     */
    public String getRole() {
        return role;
    }

    /**
     * @param role the role to set
     */
    public void setRole(String role) {
        this.role = role;
    }

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @return the insid
     */
    public String getInsid() {
        return insid;
    }

    /**
     * @param insid the insid to set
     */
    public void setInsid(String insid) {
        this.insid = insid;
    }

    /**
     * @return the stuid
     */
    public String getStuid() {
        return stuid;
    }

    /**
     * @param stuid the stuid to set
     */
    public void setStuid(String stuid) {
        this.stuid = stuid;
    }

    /**
     * @return the grade
     */
    public String getGrade() {
        return grade;
    }

    /**
     * @param grade the grade to set
     */
    public void setGrade(String grade) {
        this.grade = grade;
    }
}
