/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.Lambton.entities;

/**
 *
 * @author Dhanesh
 */
public class student {
    private String STU_ID;
    private String STU_FIRST_NAME;
    private String STU_LAST_NAME;
    private String STU_DOB;
    private String STU_SEX;
    private String STU_ADDRESS;
    private String STU_PHONE;
    private String INS_ID;
    private String DEP_ID;
    private String EMAIL;
    

    /**
     * @return the STU_ID
     */
    public String getSTU_ID() {
        return STU_ID;
    }

    /**
     * @param STU_ID the STU_ID to set
     */
    public void setSTU_ID(String STU_ID) {
        this.STU_ID = STU_ID;
    }

    /**
     * @return the STU_FIRST_NAME
     */
    public String getSTU_FIRST_NAME() {
        return STU_FIRST_NAME;
    }

    /**
     * @param STU_FIRST_NAME the STU_FIRST_NAME to set
     */
    public void setSTU_FIRST_NAME(String STU_FIRST_NAME) {
        this.STU_FIRST_NAME = STU_FIRST_NAME;
    }

    /**
     * @return the STU_LAST_NAME
     */
    public String getSTU_LAST_NAME() {
        return STU_LAST_NAME;
    }

    /**
     * @param STU_LAST_NAME the STU_LAST_NAME to set
     */
    public void setSTU_LAST_NAME(String STU_LAST_NAME) {
        this.STU_LAST_NAME = STU_LAST_NAME;
    }

    /**
     * @return the STU_DOB
     */
    public String getSTU_DOB() {
        return STU_DOB;
    }

    /**
     * @param STU_DOB the STU_DOB to set
     */
    public void setSTU_DOB(String STU_DOB) {
        this.STU_DOB = STU_DOB;
    }

    /**
     * @return the STU_SEX
     */
    public String getSTU_SEX() {
        return STU_SEX;
    }

    /**
     * @param STU_SEX the STU_SEX to set
     */
    public void setSTU_SEX(String STU_SEX) {
        this.STU_SEX = STU_SEX;
    }

    /**
     * @return the STU_ADDRESS
     */
    public String getSTU_ADDRESS() {
        return STU_ADDRESS;
    }

    /**
     * @param STU_ADDRESS the STU_ADDRESS to set
     */
    public void setSTU_ADDRESS(String STU_ADDRESS) {
        this.STU_ADDRESS = STU_ADDRESS;
    }

   

    /**
     * @param STU_EMAIL the STU_EMAIL to set
     */
   
    /**
     * @return the STU_PHONE
     */
    public String getSTU_PHONE() {
        return STU_PHONE;
    }

    /**
     * @param STU_PHONE the STU_PHONE to set
     */
    public void setSTU_PHONE(String STU_PHONE) {
        this.STU_PHONE = STU_PHONE;
    }

    /**
     * @return the INS_ID
     */
    public String getINS_ID() {
        return INS_ID;
    }

    /**
     * @param INS_ID the INS_ID to set
     */
    public void setINS_ID(String INS_ID) {
        this.INS_ID = INS_ID;
    }

    /**
     * @return the DEP_ID
     */
    public String getDEP_ID() {
        return DEP_ID;
    }

    /**
     * @param DEP_ID the DEP_ID to set
     */
    public void setDEP_ID(String DEP_ID) {
        this.DEP_ID = DEP_ID;
    }

    /**
     * @return the EMAIL
     */
    public String getEMAIL() {
        return EMAIL;
    }

    /**
     * @param EMAIL the EMAIL to set
     */
    public void setEMAIL(String EMAIL) {
        this.EMAIL = EMAIL;
    }

    
}
